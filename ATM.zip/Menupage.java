import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
public class Menupage {
    JFrame frame=new JFrame();
    JLabel menu=new JLabel();
    JLabel atmlabel=new JLabel();
    JButton deposit=new JButton();
    JButton withdraw=new JButton();
    JButton balance=new JButton();
    JButton Exit=new JButton();
    Integer acc_no=0;
    Menupage(Integer acc){
        acc_no=acc;

        menu.setBounds(230,5,100,30);
        menu.setText("MENU");
        menu.setBorder(BorderFactory.createLineBorder(Color.blue,2));
        menu.setFont(new Font("Arial", Font.BOLD,20));
        menu.setOpaque(true);
        menu.setHorizontalAlignment(SwingConstants.CENTER);

        atmlabel.setBounds(150,50,250,250);
        atmlabel.setOpaque(true);
        atmlabel.setBorder(BorderFactory.createBevelBorder(2));
        ImageIcon image=new ImageIcon("C:/Users/alche/OneDrive/Pictures/atm2.jpg");
        atmlabel.setIcon(image);

        deposit.setBounds(20,60,100,40);
        deposit.setFocusable(false);
        deposit.setText("DEPOSIT");
        deposit.addActionListener(bttnaction);
        withdraw.setBounds(20,150,100,40);
        withdraw.setFocusable(false);
        withdraw.setText("WITHDRAW");
        withdraw.addActionListener(bttnaction);
        balance.setBounds(430,60,100,40);
        balance.setFocusable(false);
        balance.setText("BALANCE");
        balance.addActionListener(bttnaction);
        Exit.setBounds(430,150,100,40);
        Exit.setText("EXIT");
        Exit.setFocusable(false);

        frame.add(deposit);
        frame.add(withdraw);
        frame.add(balance);
        frame.add(Exit);
        frame.add(menu);
        frame.add(atmlabel);
        frame.setSize(580,400);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    ActionListener bttnaction=new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            if(e.getSource()==withdraw){
                new Withdraw(acc_no);
            }
            if(e.getSource()==balance){
                Balance.balance(acc_no);
            }
            if(e.getSource()==deposit){
                new Deposit(acc_no);
            }
        }
    };
}
