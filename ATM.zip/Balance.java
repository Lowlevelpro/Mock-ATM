import javax.swing.*;
import java.sql.*;
public class Balance {
    public static void balance(Integer acc){
        try{
            String url="jdbc:mysql://localhost:3306/anupam";
            String user="root";
            String pass="@anupam007";
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con=DriverManager.getConnection(url,user,pass);
            String query = "select Name,balance from Account where Acc_no=?";
            PreparedStatement statement=con.prepareStatement(query);
            statement.setInt(1,acc);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                String userid=rs.getString("Name");
                Integer bal=rs.getInt("balance");
                String mess=String.format("User %s have balance of amount %d in account no %d",userid,bal,acc);
                JOptionPane.showMessageDialog(null,mess,"Message",JOptionPane.INFORMATION_MESSAGE);
            }
            statement.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("error in message");
        }
    }
}
