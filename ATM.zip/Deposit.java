import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
public class Deposit {
    JFrame frame=new JFrame();
    JLabel label=new JLabel();
    JLabel amount=new JLabel();
    JTextField text=new JTextField();
    JButton bttn=new JButton();
    Integer acc_no=0;
    Deposit(Integer acc){
        acc_no=acc;

        label.setText("DEPOSIT");
        label.setFont(new Font("Arial", Font.BOLD,20));
        label.setBounds(60,60,200,30);
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setBorder(BorderFactory.createBevelBorder(2));
        label.setOpaque(true);

        amount.setText("Enter Amount");
        amount.setBounds(20,150,140,20);
        amount.setOpaque(true);
        amount.setFont(new Font("Times New Roman",0,14));

        text.setBounds(120,145,170,30);
        text.setOpaque(true);

        bttn.setText("Deposit Here");
        bttn.setFocusable(false);
        bttn.setBounds(70,230,150,30);
        bttn.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        bttn.setHorizontalAlignment(SwingConstants.CENTER);
        bttn.addActionListener(bttnaction);

        frame.add(bttn);
        frame.add(label);
        frame.add(amount);
        frame.add(text);
        frame.setSize(350,350);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setBackground(Color.orange);
        frame.setVisible(true);
    }
    ActionListener bttnaction=new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            Integer amount=Integer.valueOf(text.getText());
            Deposit_action.deposit(acc_no,amount);
        }
    };
}
