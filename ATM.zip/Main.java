public class Main {
    public static void main(String[] args) {
        Logininfo objex=new Logininfo();
        new Login_page(objex.returninfo());
        //new Deposit();
        //new Withdraw();
    }
}