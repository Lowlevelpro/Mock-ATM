import java.util.HashMap;
public class Logininfo {
    HashMap<String,String> account=new HashMap<>();
    Logininfo(){
        account.put("34567","1234");
        account.put("98765","4321");
    }
    public HashMap returninfo(){
        return account;
    }
}
