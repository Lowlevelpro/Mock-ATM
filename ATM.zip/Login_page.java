import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.HashMap;
public class Login_page {
    JFrame frame=new JFrame("LOGIN PAGE");
    JLabel login=new JLabel();
    JLabel welcome=new JLabel();
    JLabel userlabel=new JLabel();
    JLabel passwordlabel=new JLabel();
    JTextField usertext=new JTextField();
    JPasswordField passwordfield=new JPasswordField();
    JButton loginbttn=new JButton();
    JButton resetbttn=new JButton();
    HashMap<String,String> account=new HashMap<>();
    Login_page(HashMap<String,String> log){
        account=log;

        login.setBounds(110,20,200,50);
        login.setText("LOGIN");
        login.setHorizontalAlignment(SwingConstants.CENTER);
        login.setBorder(BorderFactory.createLineBorder(Color.red,2));
        login.setOpaque(true);
        login.setFont(new Font("Arial", Font.BOLD,24));

        userlabel.setText("User Name");
        userlabel.setFont(new Font("Verdana", Font.PLAIN,16));
        userlabel.setBounds(30,100,100,30);
        userlabel.setBorder(BorderFactory.createBevelBorder(2));
        userlabel.setOpaque(true);

        welcome.setBounds(400,20,388,262);
        welcome.setOpaque(true);
        welcome.setBorder(BorderFactory.createLineBorder(Color.blue));
        ImageIcon image=new ImageIcon("C:/Users/alche/OneDrive/Pictures/SBI-Logo2.jpg");
        welcome.setIcon(image);

        passwordlabel.setText("Password");
        passwordlabel.setFont(new Font("Verdana", Font.PLAIN,16));
        passwordlabel.setBounds(30,150,100,30);
        passwordlabel.setBorder(BorderFactory.createBevelBorder(2));
        passwordlabel.setOpaque(true);

        usertext.setBounds(170,100,200,30);
        usertext.setOpaque(true);
        //usertext.setText("User name.....");
        passwordfield.setBounds(170,150,200,30);
        passwordfield.setOpaque(true);
        //passwordfield.setText("password...");

        loginbttn.setBounds(100,250,100,40);
        loginbttn.setText("LOGIN");
        loginbttn.setFocusable(false);
        loginbttn.setBorder(BorderFactory.createLineBorder(Color.green));
        loginbttn.addActionListener(bttnaction);
        resetbttn.setBounds(220,250,100,40);
        resetbttn.setText("RESET");
        resetbttn.setFocusable(false);
        resetbttn.setBorder(BorderFactory.createLineBorder(Color.green));
        resetbttn.addActionListener(bttnaction);

        frame.add(usertext);
        frame.add(passwordfield);
        frame.add(login);
        frame.add(userlabel);
        frame.add(passwordlabel);
        frame.add(welcome);
        frame.add(loginbttn);
        frame.add(resetbttn);
        frame.setLayout(null);
        frame.setBackground(Color.white);
        frame.setSize(830,400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    ActionListener bttnaction=new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            if(e.getSource()==resetbttn){
                usertext.setText("");
                passwordfield.setText("");
            }
            if(e.getSource()==loginbttn){
                String userinfo=String.valueOf(usertext.getText());
                String passkey=String.valueOf(passwordfield.getPassword());
                if(account.containsKey(userinfo)){
                    if(account.get(userinfo).equals(passkey)){
                        frame.dispose();
                        //System.out.println("User logged successfully!!");
                        Integer acc=Integer.valueOf(userinfo);
                        new Menupage(acc);
                    }
                    else{
                        JOptionPane.showMessageDialog(null,"wrong password","WARNING",JOptionPane.WARNING_MESSAGE);
                    }
                }
                else{
                    JOptionPane.showMessageDialog(null,"wrong username","WARNING",JOptionPane.WARNING_MESSAGE);
                }
            }
        }
    };
}
