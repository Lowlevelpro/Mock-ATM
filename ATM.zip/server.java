import java.sql.*;
public class server {
    public static void main(String[] args) throws Exception {
        String url="jdbc:mysql://localhost:3306/anupam";
        String user="root";
        String pass="@anupam007";
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con=DriverManager.getConnection(url,user,pass);
        Statement state=con.createStatement();
        String query="select first_name,last_name from toast where personid=21";
        ResultSet rs=state.executeQuery(query);
        if(rs.next()){
            String fname=rs.getString("first_name");
            String lname=rs.getString("last_name");
            System.out.println(fname+" "+lname);
        }
        state.close();
        con.close();
    }
}
