import javax.swing.*;
import java.sql.*;
public class Deposit_action {
    public static void deposit(Integer acc_,Integer amount){
        try{
            String url="jdbc:mysql://localhost:3306/anupam";
            String user="root";
            String pass="@anupam007";
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con=DriverManager.getConnection(url,user,pass);
            String query1="select balance from Account where acc_no=?";
            PreparedStatement statement1=con.prepareStatement(query1);
            statement1.setInt(1,acc_);
            ResultSet reS=statement1.executeQuery();
            Integer bal=0;
            while(reS.next()){
                bal=reS.getInt("balance");
            }
            statement1.close();
            bal=bal+amount;
            String query2="update Account set balance=? where acc_no=?";
            PreparedStatement statement2=con.prepareStatement(query2);
            statement2.setInt(1,bal);
            statement2.setInt(2,acc_);
            if((statement2.executeUpdate())>0){
                JOptionPane.showMessageDialog(null,"amount updated ","Message",JOptionPane.INFORMATION_MESSAGE);
            }
            statement2.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("deposit failed");
        }
    }
}
